<?php get_header(); // Load the header.php template. ?>

<div id="content">

</div><!-- #content -->

<?php get_footer(); // Load the footer.php template. ?>