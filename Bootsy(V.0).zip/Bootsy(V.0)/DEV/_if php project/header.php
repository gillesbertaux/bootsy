<!DOCTYPE html>
<html>
<head>

<title>Example</title>

<link rel="stylesheet" href="style.css" type="text/css" media="all" />

</head>

<body class="wordpress">

	<div id="container">

		<div id="header">

		</div><!-- #header -->

		<div id="main">