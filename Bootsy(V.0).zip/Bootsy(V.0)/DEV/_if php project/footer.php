			<?php get_sidebar(); // Load the sidebar.php template. ?>

		</div><!-- #main -->

		<div id="footer">

		</div><!-- #footer -->

	</div><!-- #container -->

</body>
</html>